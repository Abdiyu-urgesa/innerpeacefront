import React from "react";
import homeimg from "../assets/img/abthome.jpg";
function AboutPage() {
  return (
    <div>
       <section className="home" id="home">
      <img src={homeimg} alt="" className="" />
    </section>
    <section className="about section" id="about">
        <div className="about__container container">
          <div className="about__data">
          <h2 className="section__title">About</h2>
            <p className="about__description">
              Inner Peace was established to offer comprehensive mental health
              care to individuals in need. We strongly believe that fostering
              mental wellness benefits an individual's overall well-being due to
              its importance in life. Our organization's main objective is to
              aid people in uncovering inner peace
              Inner Peace was established to offer comprehensive mental health
              care to individuals in need. We strongly believe that fostering
              mental wellness benefits an individual's overall well-being due to
              its importance in life. Our organization's main objective is to
              aid people in uncovering inner peace
              Inner Peace was established to offer comprehensive mental health
              care to individuals in need. We strongly believe that fostering
              mental wellness benefits an individual's overall well-being due to
              its importance in life. Our organization's main objective is to
              aid people in uncovering inner peace
              Inner Peace was established to offer comprehensive mental health
              care to individuals in need. We strongly believe that fostering
              mental wellness benefits an individual's overall well-being due to
              its importance in life. Our organization's main objective is to
              aid people in uncovering inner peace
            </p>
          </div>
        </div>
      </section>
      <section className="about section" id="about">
        <div className="about__container container">
          <div className="about__data">
          <h2 className="section__title">Mission</h2>
            <p className="about__description">
              Inner Peace was established to offer comprehensive mental health
              care to individuals in need. We strongly believe that fostering
              mental wellness benefits an individual's overall well-being due to
              its importance in life. Our organization's main objective is to
              aid people in uncovering inner peace
              Inner Peace was established to offer comprehensive mental health
              care to individuals in need. We strongly believe that fostering
              mental wellness benefits an individual's overall well-being due to
              its importance in life. Our organization's main objective is to
              aid people in uncovering inner peace
              Inner Peace was established to offer comprehensive mental health
              care to individuals in need. We strongly believe that fostering
              mental wellness benefits an individual's overall well-being due to
              its importance in life. Our organization's main objective is to
              aid people in uncovering inner peace
              Inner Peace was established to offer comprehensive mental health
              care to individuals in need. We strongly believe that fostering
              mental wellness benefits an individual's overall well-being due to
              its importance in life. Our organization's main objective is to
              aid people in uncovering inner peace
            </p>
          </div>
        </div>
      </section>
      <section className="about section" id="about">
        <div className="about__container container ">
          <div className="about__data">
          <h2 className="section__title">Vision</h2>
            <p className="about__description">
              Inner Peace was established to offer comprehensive mental health
              care to individuals in need. We strongly believe that fostering
              mental wellness benefits an individual's overall well-being due to
              its importance in life. Our organization's main objective is to
              aid people in uncovering inner peace
              Inner Peace was established to offer comprehensive mental health
              care to individuals in need. We strongly believe that fostering
              mental wellness benefits an individual's overall well-being due to
              its importance in life. Our organization's main objective is to
              aid people in uncovering inner peace
              Inner Peace was established to offer comprehensive mental health
              care to individuals in need. We strongly believe that fostering
              mental wellness benefits an individual's overall well-being due to
              its importance in life. Our organization's main objective is to
              aid people in uncovering inner peace
              Inner Peace was established to offer comprehensive mental health
              care to individuals in need. We strongly believe that fostering
              mental wellness benefits an individual's overall well-being due to
              its importance in life. Our organization's main objective is to
              aid people in uncovering inner peace
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}

export default AboutPage;
